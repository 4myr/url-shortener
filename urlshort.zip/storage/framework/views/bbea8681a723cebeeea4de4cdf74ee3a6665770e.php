<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(env('APP_NAME')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(env('APP_URL')); ?><?php echo e(mix('/js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('headJS'); ?>

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(env('APP_URL')); ?><?php echo e(mix('/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(env('APP_URL')); ?><?php echo e(mix('/css/main.css')); ?>">
    <?php echo $__env->yieldContent('headCSS'); ?>

    <!-- Fonts -->

</head>
<body>
    <nav class="navbar navbar-expand-sm navbar-dark pb-3">
        <a class="navbar-brand pull-right pl-" href="#">
            <img class="logo img-responsive" src="<?php echo e(asset('images/logo.png')); ?>" alt="URL Shortener">
        </a>
        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId"
                aria-controls="collapsibleNavId"
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
                <li class="nav-item active pl-lg-3">
                    <a class="nav-link" href="#">خانه <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item pl-lg-3">
                    <a class="nav-link" href="#">درباره ما</a>
                </li>
                <li class="nav-item pl-lg-3">
                    <a class="nav-link" href="#">تماس با ما</a>
                </li>
            </ul>
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <li class="nav-item pl-lg-3">
                    <a class="nav-link" href="#">ورود</a>
                </li>
                <li class="nav-item pl-lg-3 pr-lg-3">
                    <a class="nav-link cl-secondary" href="#">ثبت نام</a>
                </li>
            </ul>
        </div>
    </nav>
    <?php echo $__env->yieldContent('content'); ?>

    <footer class="footer container-fluid pt-4 pb-2">
        <p>تمامی حقوق برای این سایت محفوظ است. © 1399</p>
        <p>طراحی و توسعه توسط <a href="https://xenops.ir" class="font-weight-bold">زیناپس</a></p>
    </footer>
</body>
</html>
<?php /**PATH C:\wamp64\www\urlshort\resources\views/layouts/frontend.blade.php ENDPATH**/ ?>