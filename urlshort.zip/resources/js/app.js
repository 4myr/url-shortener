require('./bootstrap');
require('../../node_modules/jquery/dist/jquery.slim.min.js');
require('../../node_modules/popper.js/dist/popper.min');
